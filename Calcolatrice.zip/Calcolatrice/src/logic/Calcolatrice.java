package logic;
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class Calcolatrice extends Application{
	
	@FXML private Button btn1;
	@FXML private Button btn2;
	@FXML private Button btn3;
	@FXML private Button btn4;
	@FXML private Button btn5;
	@FXML private Button btn6;
	@FXML private Button btn7;
	@FXML private Button btn8;
	@FXML private Button btn9;
	@FXML private Button btn0;
	@FXML private Button btnPlus;
	@FXML private Button btnMinus;
	@FXML private Button btnDiv;
	@FXML private Button btnMol;
	@FXML private Button btnCanc;
	@FXML private Button btnEqual;
	
	@FXML TextField tfShow;
	
	private Integer a = null;
	private Integer b = null;
	private Integer ris = null;
	private String op = new String();

	@Override
	public void start(Stage primaryStage) throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("modello.fxml"));
		Scene scene = new Scene(root);
		
		primaryStage.setScene(scene);
		primaryStage.show();
		
	}
	
	public static void main(String[] args) {
		launch(args);
	}
	
	@FXML
	public void btn1Controller() {
		tfShow.setText(tfShow.getText() + "1");
		
	}
	@FXML
	public void btn2Controller() {
		tfShow.setText(tfShow.getText() + "2");
		
	}
	@FXML
	public void btn3Controller() {
		tfShow.setText(tfShow.getText() + "3");
		
	}
	@FXML
	public void btn4Controller() {
		tfShow.setText(tfShow.getText() + "4");
		
	}
	@FXML
	public void btn5Controller() {
		tfShow.setText(tfShow.getText() + "5");
		
	}
	@FXML
	public void btn6Controller() {
		tfShow.setText(tfShow.getText() + "6");
		
	}
	@FXML
	public void btn7Controller() {
		tfShow.setText(tfShow.getText() + "7");
		
	}
	@FXML
	public void btn8Controller() {
		tfShow.setText(tfShow.getText() + "8");
		
	}
	@FXML
	public void btn9Controller() {
		tfShow.setText(tfShow.getText() + "9");
		
	}
	@FXML
	public void btn0Controller() {
		tfShow.setText(tfShow.getText() + "0");
		
	}
	
	@FXML
	public void add() {
		
		op = "add";
		a = Integer.parseInt(tfShow.getText());
		tfShow.setText("");
		
	}
	@FXML
	public void sot() {
		op = "sott";
		a = Integer.parseInt(tfShow.getText());
		tfShow.setText("");
		
	}
	@FXML
	public void div() {
		op = "div";
		a = Integer.parseInt(tfShow.getText());
		tfShow.setText("");
		
		
	}
	@FXML
	public void mol() {
		op = "mol";
		a = Integer.parseInt(tfShow.getText());
		tfShow.setText("");
		
	}
	@FXML
	public void logaritmo() {
		a = Integer.parseInt(tfShow.getText());
		
		Double ris2 = Math.log(a);
		tfShow.setText(ris2.toString());
	}
	@FXML
	public void canc() {
		tfShow.setText(" ");
	}
	@FXML
	public void equal() {
		
		b = Integer.parseInt(tfShow.getText());
		
		if(op == "add") {
			ris = a+b;
		}
		if( op == "sott") {
			ris = a-b;
		}
		if(op == "div") {
			
			ris =  a/b ;
		}
		if(op == "mol") {
			ris =  a*b;
		}
		tfShow.setText(ris.toString());
		
		
	}
}
